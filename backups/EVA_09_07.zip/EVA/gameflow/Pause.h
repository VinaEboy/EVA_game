#ifndef __PAUSE__
#define __PAUSE__

typedef struct pause_game {
    unsigned char Back_to_title_screen;
} pause_game;

void start_pause();
void show_pause();

#endif
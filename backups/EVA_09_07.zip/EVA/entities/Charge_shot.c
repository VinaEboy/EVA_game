#include "Charge_shot.h"
#include <stdlib.h>
#include <stdio.h>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_primitives.h>

void shot_1() {

}

void shot_2() {

}

void shot_3() {

}

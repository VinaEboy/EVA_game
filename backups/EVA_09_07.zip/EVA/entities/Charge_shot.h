#ifndef __CHARGE_SHOT__
#define __CHARGE_SHOT__

void shot_1();
void shot_2();
void shot_3();

#endif
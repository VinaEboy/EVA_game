#ifndef __LOAD_GAME__
#define __LOAD_GAME__

typedef struct load_game {
    unsigned char Slot_1;
} load_game;

void start_load_game( );
void show_load_game ( );

#endif
#include "Load_game.h"

void start_load_game( ) {
    return;
}

void show_load_game ( ) {
    return;
}
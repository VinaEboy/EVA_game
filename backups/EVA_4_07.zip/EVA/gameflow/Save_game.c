#include "Save_game.h"

void start_save_game ( ) {
    return ;
}

void show_save_game ( ) {
    return ;
}


#ifndef __LEVEL_1__
#define __LEVEL_1__

#include "Title_screen.h"
#include "Level_1.h"

typedef struct level_1 {
    unsigned char inicio;
} level_1;

void start_level_1( );

void show_level_1( );

#endif
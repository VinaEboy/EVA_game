#ifndef __SAVE_GAME__
#define __SAVE_GAME__

void start_save_game();
void show_save_game();

#endif
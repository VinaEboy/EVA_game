#ifndef __COLLISIONS__
#define __COLLISIONS__

#include "Objects.h"

struct Player;
struct Jet_alone;

/// COLISOES
//status 0: não colidiu
//status 1: Estava acima da plataforma e colidiu
//status 2: Estava abaixo da plataforma e colidiu (como se fosse um teto)
//status 3: Estava no lado esquerdo da plataforma e colidiu
//status 4: Estava no lado direito da plataforma e colidiu

int player_check_collision_with_platform(struct Player *player, Platform *platform);

void player_resolve_collision_with_platform(struct Player *player, Platform *platform, int status);

#endif
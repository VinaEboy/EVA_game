#include "Collisions.h"

#include "../entities/Player.h"
#include "../entities/Jet_alone.h"
#include <stdio.h>

//a chave para a chegagem é saber que o centro do jogador não está atualizado, ou seja
//a coordenada x e y é aonde o jogador quer ir e a coordenada center_x center_y fala aonde ele estava
int player_check_collision_with_platform(struct Player *player, Platform *platform) {
    // Coordenadas do frame atual
    float player_x1 = player->x;
    float player_x2 = player->x + EVA_WIDTH;
    float player_y1 = player->y;
    float player_y2 = player->y + EVA_HEIGHT;

    float plat_x1 = platform->x;
    float plat_x2 = platform->x + platform->width;
    float plat_y1 = platform->y;
    float plat_y2 = platform->y + platform->height;

    // 1. Checar se há colisão usando o método AABB correto
    if (player_x2 <= plat_x1 || player_x1 >= plat_x2 || player_y2 <= plat_y1 || player_y1 >= plat_y2) {
        if (player_x2 <= plat_x1) printf("AAA\n");
        if (player_x1 >= plat_x2) printf("BBB\n");
        if (player_y2 <= plat_y1) printf("CCC\n");
        if (player_y1 >= plat_y2) printf("DDD\n");
        return 0; // Sem colisão
    }

    // 2. Se colidiu, calcular a profundidade da sobreposição em cada eixo
    float overlap_x1 = player_x2 - plat_x1; // Overlap vindo da esquerda
    float overlap_x2 = plat_x2 - player_x1; // Overlap vindo da direita
    float overlap_y1 = player_y2 - plat_y1; // Overlap vindo de cima
    float overlap_y2 = plat_y2 - player_y1; // Overlap vindo de baixo

    // Achar a menor sobreposição para X e Y
    float overlap_x = (overlap_x1 < overlap_x2) ? overlap_x1 : overlap_x2;
    float overlap_y = (overlap_y1 < overlap_y2) ? overlap_y1 : overlap_y2;

    // 3. A direção da colisão é o eixo com a MENOR sobreposição
    if (overlap_y < overlap_x) {
        // --- COLISÃO VERTICAL ---
        
        // Usamos a posição anterior (ou a velocidade) para saber se veio de cima ou de baixo
        // center_y aqui é a posição Y do centro no frame anterior
        if (player->center_y < plat_y1) {
            return 1; // Estava acima e pousou
        } else {
            return 2; // Estava abaixo e bateu a cabeça
        }

    } else {
        // --- COLISÃO HORIZONTAL ---

        // Usamos a posição anterior (ou a velocidade) para saber o lado
        // center_x aqui é a posição X do centro no frame anterior
        if (player->center_x < plat_x1) {
            return 3; // Estava à esquerda e colidiu
        } else {
            return 4; // Estava à direita e colidiu
        }
    }
}

//reposiciona o player de acordo com o tipo de colisão que sofreu
void player_resolve_collision_with_platform(struct Player *player, Platform *platform, int status) {

    //colidiu com a plataforma verticalmente
    if (status == 1) {
        player->y = platform->y - EVA_HEIGHT;
        player->vy = 0;
        player->is_on_ground = 1;
    }
    else if (status == 2) {
        player->y = platform->y + platform->height;
        player->vy = 0;
    }
    else if (status == 3) {
        player->x = platform->x - EVA_WIDTH;
    }
    else if (status == 4) {
        player->x = platform->x + platform->width;
    }
}


#include "Pause.h"

void start_pause( ) {
    return;
}

void show_pause( ) {
    return;
}
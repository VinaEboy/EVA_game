#ifndef __LEVEL_SACHIEL__
#define __LEVEL_SACHIEL__

#include "Title_screen.h"
#include "Level_Sachiel.h"


void start_level_sachiel( );

void show_level_sachiel( );

#endif
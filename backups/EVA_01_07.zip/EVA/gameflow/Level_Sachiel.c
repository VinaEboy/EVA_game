#include <stdlib.h>
#include <stdio.h>
#include <allegro5/allegro5.h>																																												
#include <allegro5/allegro_font.h>																																											
#include <allegro5/allegro_primitives.h>			

#include "Level_Sachiel.h"
#include "Game_state.h"


void start_level_sachiel( ) {
    return;
}

void show_level_sachiel( ) {
    return;
}
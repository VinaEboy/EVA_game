#include <allegro5/allegro5.h>																																												
#include <allegro5/allegro_font.h>																																											
#include <allegro5/allegro_primitives.h>																																									


void abrir_pausa() {
    return;

}

void abrir_inventario() {
    return;

}

void fechar_pausa() {
    return;

}

void fechar_inventario() {
    return;
    
}